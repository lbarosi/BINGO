---
title: "BINGO Sites"
author: "Luciano Barosi"
output: html_document
---

# Instructions

Download the file in the link below. This is a html widget where you view the maps and interact with them directly from your browser.

![Campanha-01](https://github.com/lbarosi/BINGO/blob/master/VisitedSites/READMEvisited.html)
